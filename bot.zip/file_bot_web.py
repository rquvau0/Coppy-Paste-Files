#!/usr/bin/env python3
"""
File Bot Web - giao diện web (index.html) + xử lý file bằng Python.
Cách chạy:  python file_bot_web.py   (giữ index.html cùng thư mục)
Chỉ dùng thư viện có sẵn của Python, không cần cài thêm.
"""
import json
import shutil
import subprocess
import sys
import threading
import unicodedata
import webbrowser
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HOST, PORT = "127.0.0.1", 8765          # chỉ mở trên máy bạn
THU_MUC = Path(__file__).resolve().parent


# ---------------------- Tiện ích ----------------------
def sach(text) -> str:
    return (text or "").strip().strip('"').strip("'")


def chuan(ten: str) -> str:
    return unicodedata.normalize("NFC", ten).lower()


def thu_muc(text, tao=False) -> Path:
    s = sach(text)
    if not s:
        raise ValueError("Chưa nhập đường dẫn")
    p = Path(s).expanduser()
    if tao:
        p.mkdir(parents=True, exist_ok=True)
    elif not p.is_dir():
        raise ValueError(f"Thư mục không tồn tại: {p}")
    return p.resolve()


def lay_ds(goc: Path, de_quy=False, loai_tru: Path | None = None) -> list[Path]:
    try:
        ds = [p for p in (goc.rglob("*") if de_quy else goc.iterdir()) if p.is_file()]
    except OSError:
        return []
    if loai_tru is not None:
        ds = [p for p in ds if loai_tru not in p.parents]

    def khoa(p: Path):
        rel = p.relative_to(goc)
        return (len(rel.parts) > 1, str(rel.parent).lower(), p.name.lower())

    return sorted(ds, key=khoa)


def khong_trung(dich: Path) -> Path:
    if not dich.exists():
        return dich
    i = 1
    while True:
        moi = dich.with_name(f"{dich.stem} ({i}){dich.suffix}")
        if not moi.exists():
            return moi
        i += 1


def lam_sach_ten(ten: str) -> str:
    for ch in '<>:"/\\|?*':
        ten = ten.replace(ch, "_")
    return ten.strip().rstrip(".")


# ---------------------- API ----------------------
def api_list(d):
    nguon, dich = thu_muc(d.get("nguon")), thu_muc(d.get("dich"), tao=True)
    da_co = {chuan(f.name) for f in lay_ds(dich)}
    files = [{"rel": f.relative_to(nguon).as_posix(), "co": chuan(f.name) in da_co}
             for f in lay_ds(nguon, d.get("con", True), dich)]
    return {"files": files, "nguon": str(nguon), "dich": str(dich)}


def api_dest(d):
    nguon, dich = thu_muc(d.get("nguon")), thu_muc(d.get("dich"), tao=True)
    o_nguon = {chuan(f.name) for f in lay_ds(nguon, d.get("con", True), dich)}
    return {"files": [{"name": f.name, "co": chuan(f.name) in o_nguon} for f in lay_ds(dich)]}


def api_copy(d):
    nguon, dich = thu_muc(d.get("nguon")), thu_muc(d.get("dich"), tao=True)
    dong, ok = [], 0
    # Thứ tự của danh sách "chon" chính là thứ tự ở khu vực "Xem trước vị trí"
    chon = list(d.get("chon", []))[::-1]    # luôn chép từ cuối lên đầu
    for rel in chon:
        src = (nguon / rel).resolve()
        if nguon not in src.parents or not src.is_file():
            dong.append(f"[BỎ QUA] {rel} (không tìm thấy file)")
            continue
        try:
            shutil.copy2(src, khong_trung(dich / src.name))
            if d.get("xoa_goc"):
                src.unlink()
            dong.append(f"[OK] {rel}")
            ok += 1
        except Exception as e:
            dong.append(f"[LỖI] {rel}: {e}")
    dong.append(f"Hoàn tất: {ok}/{len(d.get('chon', []))} file.")
    return {"dong": dong}


def api_delete(d):
    dich = thu_muc(d.get("dich"))
    dong, ok = [], 0
    vi_tri = {f.name: i for i, f in enumerate(lay_ds(dich))}
    for ten in sorted(d.get("chon", []), key=lambda t: vi_tri.get(t, -1), reverse=True):  # từ cuối lên đầu
        if ten != Path(ten).name:      # chặn đường dẫn lạ
            dong.append(f"[LỖI] {ten}: tên không hợp lệ")
            continue
        try:
            (dich / ten).unlink()
            dong.append(f"[ĐÃ XÓA] {ten}")
            ok += 1
        except Exception as e:
            dong.append(f"[LỖI] {ten}: {e}")
    dong.append(f"Hoàn tất: đã xóa {ok}/{len(d.get('chon', []))} file.")
    return {"dong": dong}


def api_backup(d):
    dich = thu_muc(d.get("dich"))
    if not sach(d.get("goc")):
        raise ValueError("Chưa nhập nơi lưu backup")
    ten = lam_sach_ten(d.get("ten", "")) or datetime.now().strftime("%d_%m_%Y_%H_%M")
    dst = khong_trung(Path(sach(d["goc"])).expanduser() / ten)
    dst.mkdir(parents=True)
    chon = d.get("chon", [])
    if d.get("che_do") == "nguon":
        # backup các file đã chọn ở nguồn, theo thứ tự ở khu vực "Xem trước vị trí"
        nguon = thu_muc(d.get("nguon"))
        files = []
        for rel in chon:
            src = (nguon / rel).resolve()
            if nguon in src.parents and src.is_file():
                files.append(src)
    else:
        # backup các file đã tích ở thư mục đích (theo thứ tự danh sách)
        ten_chon = set(chon)
        files = [f for f in lay_ds(dich) if f.name in ten_chon]
    dong, ok = [], 0
    for f in reversed(files):    # từ cuối lên đầu
        try:
            shutil.copy2(f, khong_trung(dst / f.name))
            ok += 1
        except Exception as e:
            dong.append(f"[LỖI] {f.name}: {e}")
    return {"dong": [f"Đã tạo backup: {dst}", f"Sao chép thành công {ok}/{len(files)} file."] + dong}


def api_browse(d):
    """Mở hộp thoại chọn thư mục của hệ điều hành."""
    code = ("import tkinter as tk\nfrom tkinter import filedialog\n"
            "r=tk.Tk();r.withdraw();r.attributes('-topmost',True)\n"
            "sys=__import__('sys');sys.stdout.buffer.write((filedialog.askdirectory() or '').encode('utf-8'))")
    out = subprocess.run([sys.executable, "-c", code], capture_output=True).stdout
    return {"path": out.decode("utf-8", "replace").strip()}


ROUTES = {"/api/list": api_list, "/api/dest": api_dest, "/api/copy": api_copy,
          "/api/delete": api_delete, "/api/backup": api_backup, "/api/browse": api_browse}


# ---------------------- Server ----------------------
def tim_giao_dien() -> Path | None:
    """Tìm file giao diện: ưu tiên index.html, nếu không có thì lấy file dạng index*.html (vd 'index (1).html')."""
    p = THU_MUC / "index.html"
    if p.is_file():
        return p
    ds = sorted(THU_MUC.glob("index*.html"))
    return ds[0] if ds else None


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _gui(self, code, body: bytes, ctype):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _host_ok(self) -> bool:      # chống DNS rebinding
        return self.headers.get("Host", "") in (f"{HOST}:{PORT}", f"localhost:{PORT}")

    def do_GET(self):
        if self.path not in ("/", "/index.html") or not self._host_ok():
            return self._gui(404, b"Not found", "text/plain")
        try:
            p = tim_giao_dien()
            if p is None:
                msg = (f"Không tìm thấy file index.html trong thư mục:\n{THU_MUC}\n\n"
                       "Hãy để index.html CÙNG THƯ MỤC với file_bot_web.py rồi tải lại trang.")
                return self._gui(404, msg.encode("utf-8"), "text/plain; charset=utf-8")
            self._gui(200, p.read_bytes(), "text/html; charset=utf-8")
        except Exception as e:
            self._gui(500, f"Lỗi khi đọc giao diện: {e}".encode("utf-8"), "text/plain; charset=utf-8")

    def do_POST(self):
        fn = ROUTES.get(self.path)
        # Header tự đặt X-Bot buộc trình duyệt phải xin phép (CORS) -> trang web lạ không gọi được
        if not fn or not self._host_ok() or self.headers.get("X-Bot") != "1":
            return self._gui(403, b"Forbidden", "text/plain")
        try:
            n = int(self.headers.get("Content-Length", 0))
            kq = fn(json.loads(self.rfile.read(n) or b"{}"))
        except Exception as e:
            kq = {"loi": str(e)}
        self._gui(200, json.dumps(kq, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")


def main():
    url = f"http://{HOST}:{PORT}"
    srv = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"File Bot đang chạy tại {url}  (Ctrl+C để thoát)")
    if tim_giao_dien() is None:
        print(f"[CẢNH BÁO] Không thấy index.html trong: {THU_MUC}\n           Hãy để index.html cùng thư mục với file này.")
    threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nĐã thoát.")


if __name__ == "__main__":
    main()
